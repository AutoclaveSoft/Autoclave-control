RUS
Установите на ПК/ноутбук шрифт с названием Minecraft Rus Regular (minecraft.ttf)
Сделать это можно, кликнув 2 раза на файл, далее в окне кнопку "Установить"
После этого разархивируйте ZIP-файл в любую папку на устройстве (не удаляйте файлы!)
Может создать ярлык на Рабочем столе для быстрого доступа к приложению
Вес приложения примерно 35-38 Мб
Вес ZIP-файла 11 Мб

EN
Install a font named Minecraft Rus Regular (minecraft.ttf) on your PC/laptop
You can do this by clicking on the file 2 times, then click Install in the window
After that, unzip the ZIP file to any folder on your device (do not delete files!)
You can create a shortcut on your Desktop for quick access to the application.
The application weight is approximately 35-38 MB
The ZIP file weight is 11 MB